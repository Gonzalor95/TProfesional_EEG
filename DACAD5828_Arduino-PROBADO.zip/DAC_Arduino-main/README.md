# DAC_Arduino
In this tutorial, the demonstration of using a Arduino and Digital to Analog Converter (DAC) as a analog signal generator is presented. The AD5308 DAC and Arduino Nano are used to demonstrated.
