//---------------------------------------------------------------------------

#include <vcl.h>

#pragma hdrstop

#include "pruebalibreria.h"
#include "edflib.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
struct edf_hdr_struct hdr;
int hdl,numcan,frecmuestreo;            
AnsiString NomArch;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{

 time_t timer;
 struct tm *tblock;
 /* gets time of day */
 timer = time(NULL);
 /* converts date/time to a structure */
 tblock = localtime(&timer);

  OpenDialog1->Filter= "edf records (*.edf)|*.edf|All files (*.*)|*.*";
  if (OpenDialog1->Execute())
 {
   NomArch=OpenDialog1->FileName;
  }


  if(edfopen_file_readonly(NomArch.c_str(), &hdr, EDFLIB_DO_NOT_READ_ANNOTATIONS))
 {

    switch(hdr.filetype)
    {
      case EDFLIB_MALLOC_ERROR                : printf("\nmalloc error\n\n");
                                                break;
      case EDFLIB_NO_SUCH_FILE_OR_DIRECTORY   : printf("\ncan not open file, no such file or directory\n\n");
                                                break;
      case EDFLIB_FILE_CONTAINS_FORMAT_ERRORS : printf("\nthe file is not EDF(+) or BDF(+) compliant\n"
                                                       "(it contains format errors)\n\n");
                                                break;
      case EDFLIB_MAXFILES_REACHED            : printf("\nto many files opened\n\n");
                                                break;
      case EDFLIB_FILE_READ_ERROR             : printf("\na read error occurred\n\n");
                                                break;
      case EDFLIB_FILE_ALREADY_OPENED         : printf("\nfile has already been opened\n\n");
                                                break;
      default                                 : printf("\nunknown error\n\n");
                                                break;
      }
    }

    hdl = hdr.handle;
    Memo1->Lines->Clear();
    AnsiString resultado;
    AnsiString otro;
    numcan=hdr.edfsignals;
    resultado= "Cantidad de canales = "+ IntToStr(numcan);
    Memo1->Lines->Append(resultado);
    if(hdr.startdate_year > tblock->tm_year+1900) hdr.startdate_year=hdr.startdate_year-100;
    resultado= "Fecha estudio: "+IntToStr(hdr.startdate_day)+"/"+IntToStr(hdr.startdate_month)+"/"+IntToStr(hdr.startdate_year);
    Memo1->Lines->Append(resultado);
    Memo1->Lines->Append(hdr.patient);
    resultado=" Duraci�n en horas :" ;
    otro=((double)hdr.datarecord_duration)/ EDFLIB_TIME_DIMENSION;
    Memo1->Lines->Append(StrCat(resultado.c_str(),otro.c_str()));
    frecmuestreo= hdr.signalparam[1].smp_in_datarecord;
    resultado="N� de muestras por segundo = "+ IntToStr(frecmuestreo);
    Memo1->Lines->Append(resultado);
}
//---------------------------------------------------------------------------
